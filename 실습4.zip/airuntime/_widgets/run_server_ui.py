from genericpath import exists
import time
import asyncio
import multiprocessing
import os
import logging
from termcolor import colored as _colored

import os
import json
from typing import Union, List, Dict, Tuple
import numpy as np
import pandas as pd

from ipywidgets import Button, Layout, Output, HBox, VBox, Text, Dropdown
from IPython.display import display

from ipyfilechooser import FileChooser as _FileChooser

import kfserving as _kfserving
import ray as _ray 

import sys
import shutil

from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter


try:
    from startup import (
        _infer_schema_pyspark_to_pandas_sandbox,
        _infer_decimal,
        _load_schema,
        _read_pandas_df,
    )
except ImportError:
    try:
        from ..startup import (
            _infer_schema_pyspark_to_pandas_sandbox,
            _infer_decimal,
            _load_schema,
            _read_pandas_df,
        )
    except ImportError:
        _BASE_PATH_ = "/home/work"
        _PACKAGE_ROOT_ = os.path.join(_BASE_PATH_, "airuntime")
        _PACKAGE_PATH_ = [
            os.path.join(_PACKAGE_ROOT_, p) for p in os.listdir(_PACKAGE_ROOT_)
            if os.path.isdir(os.path.join(_PACKAGE_ROOT_, p)) or os.path.basename(p).endswith(".py")
        ]
        sys.path.insert(0, _BASE_PATH_)
        sys.path.insert(-1, _PACKAGE_ROOT_)
        for _p in _PACKAGE_PATH_:
            sys.path.insert(0, _p)

        from startup import (
            _infer_schema_pyspark_to_pandas_sandbox,
            _infer_decimal,
            _load_schema,
            _read_pandas_df,
        )


import importlib


_parser = ArgumentParser(formatter_class=ArgumentDefaultsHelpFormatter)
_parser.add_argument("-k", "--kind", help='model type ["sklearn", "tensorflow", "pytorch"]', required=True)
_args = vars(_parser.parse_args())
_DEFAULT_MODEL_TYPE_ = _args["kind"]

assert _DEFAULT_MODEL_TYPE_ in ["sklearn", "tensorflow", "pytorch"]
_MODEL_TYPE_LIST_ = [_DEFAULT_MODEL_TYPE_]

_FW_VERSION_DICT_ = {
    "sklearn": "0.24.2",  # "0.21.3"
    "tensorflow": "2.2.0",
    "pytorch": "1.6.0",
}

_DATA_TYPE_LIST_ = [
    "Tabular",
    "Image",
    "Text",
]
_DEFAULT_DATA_TYPE_ = _DATA_TYPE_LIST_[0]

_ESTM_TYPE_LIST_ = [
    "others",
    "classifier",
    "regressor",
]
_DEFAULT_ESTM_TYPE_ = _ESTM_TYPE_LIST_[0]

try:
    if "_TARGET_COL_" in vars() or "_TARGET_COL_" in globals():
        global _TARGET_COL_
        if _TARGET_COL_ is not None:
            _DEFAULT_TARGET_COL_ = _TARGET_COL_
        else:
            raise Exception("'_TARGET_COL_' is None.")
    else:
        raise Exception("'_TARGET_COL_' is not defined.")
except:
    _DEFAULT_TARGET_COL_ = ""

_base_data_dir_ = os.path.join(_BASE_PATH_, "dataset")
if not os.path.isdir(_base_data_dir_):
    os.makedirs(_base_data_dir_, exist_ok=True)
_schema_path_ = os.path.join(_base_data_dir_, ".columns.json")
if os.path.exists(_schema_path_):
    os.remove(_schema_path_)

if _ray.is_initialized():
    _ray.shutdown()

_ray.init(
    num_cpus=1,
    num_gpus=None,
    local_mode=False,
    # object_store_memory=(75 * 1024 * 1024),
    # _memory=(200 * 1024 * 1024),
    _redis_max_memory=(100 * 1024 * 1024),
    include_dashboard=False,
    configure_logging=False,
    logging_level=logging.INFO,
    ignore_reinit_error=True,
    _plasma_directory="/tmp",
    _system_config={
        "automatic_object_spilling_enabled": True,
        "object_spilling_config": json.dumps(
            {"type": "filesystem", "params": {"directory_path": "/tmp/spill"}},
        )
    },
)
_RAY_ROTATION_BACKUP_COUNT_ = 1


if os.path.exists(_schema_path_):
    os.remove(_schema_path_)


def _infer_schema_pandas_to_pyspark_standalone(data_frame: pd.DataFrame) -> Dict:
    import pyspark
    from pyspark import SparkContext, SparkConf
    from pyspark.sql import SparkSession


    conf = SparkConf().setAppName("pysparkApp")
    conf.set("spark.sql.execution.arrow.pyspark.enabled", "true")
    spark = SparkSession.builder.config(conf=conf).getOrCreate()
    sc = spark.sparkContext

    spark_df = spark.createDataFrame(data_frame)
    labels = [c.name for c in spark_df.schema]
    types = [str(c.dataType) for c in spark_df.schema]
    return {"labels": labels, "types": types}


class _LogToQueue(logging.Handler):
    def __init__(self, queue=None):
        self.q = queue if queue else multiprocessing.Queue()
        logging.Handler.__init__(self)
    def write(self,x):
        return self.q.put(x)
    def put(self,x):
        return self.q.put(x)
    def get(self):
        return self.q.get()
    def empty(self):
        return self.q.empty()
    def print(self, x, end='\n'):
        self.write(str(x) + end)


@_ray.remote  # (memory=(50 * 1024 * 1024))  # 50MB
class _InternalServer:
    def __init__(self, model_name="test", model_dir=None, model_kind=None):
        self.model_name = model_name
        self.model_dir = model_dir
        self.model_kind = model_kind
        import sys
        sys.path.insert(0, _BASE_PATH_)
        self.model_module = importlib.import_module(
            f"airuntime.{self.model_kind}.{self.model_kind.split('_')[0]}server")
        self.model = self.model_module.inferencer.model.ServingModel(
            self.model_name, self.model_dir
        )
        try:
            self.model.load()
            self.ready = True
        except Exception as e:
            self.ready = False
            raise e

    async def run(self, port=8080):
        self.port = port
        # For KFServer IOLoop
        try:
            #asyncio.set_event_loop(asyncio.new_event_loop())
            self.server = _kfserving.KFServer(
                http_port=self.port,
                registered_models=self.model_module.inferencer.model_repository.ModelRepository(
                    self.model_dir
                )
            )
            await self.server.start([self.model])
        except RuntimeError as re:
            pass

@_ray.remote  # (memory=(50 * 1024 * 1024))  # 50MB
class _RunActorAsync:
    def __init__(self, actor):
        self.actor = actor

    async def run(self, *args, **kwargs):
        try:
            # Coroutine will switch context when "await" is called.
            res = await self.actor.run.remote(*args, **kwargs)
        except Exception as e:
            raise e


def _write_schema(dataset: pd.DataFrame, data_path=None, estimator_type="classifier"):
    global _schema_path_
    os.makedirs(os.path.dirname(os.path.abspath(_schema_path_)), exist_ok=True)
    if data_path is None:
        data_path = ".dummy.csv"
        dataset.to_csv(data_path, index=False)
    with open(_schema_path_, "w") as f:
        json.dump(
            {
                "filename": os.path.basename(data_path),
                "columns": dataset.dtypes.index.tolist(),
                "datatypes": [d.name for d in dataset.dtypes],
                "estimatorType": estimator_type,
            },
            f,
        )


def _write_model_flag(
        model_type: str="sklearn",
        data_type: str="Tabular",
        ):
    fw_name = model_type
    if fw_name == "pytorch":
        pkg_name = "torch"
    else:
        pkg_name = fw_name
    fw_module = importlib.import_module(pkg_name)
    try:
        fw_version = fw_module.__version__ if fw_module.__version__ else _FW_VERSION_DICT_.get(pkg_name)
    except AttributeError:
        fw_version = _FW_VERSION_DICT_.get(pkg_name)
    model_flag = """# This file is a SYSTEM-GENERATED file. DO NOT EDIT THIS!!!

MODEL_TYPE={model_type}
FW={fw_name}
FW_VERSION={fw_version}
DATA_TYPE={data_type}
MODEL_TEST=/home/work/airuntime/{model_type}/test_server.py
""".format(
    model_type=model_type,
    fw_name=fw_name,
    fw_version=fw_version,
    data_type=data_type,
)
    print(model_flag)
    print(data_type.lower())
    with open(_schema_path_, "r") as f:
        custom_schema = json.load(f)
    custom_name = custom_schema.get("filename")
    if data_type.lower() == "tabular":
        try:
            data_info, data_path = _load_schema()
            data_path = data_path.split(_BASE_PATH_ + os.path.sep)[-1]
            data_name = os.path.basename(data_path)
            if data_name == custom_name:
                model_flag += "PIPELINE_SCHEMA={pipeline_schema}\n".format(
                    pipeline_schema=json.dumps(data_info["schema"])
                )
            else:
                # custom_data_path = os.path.join(_BASE_PATH_, "dataset", custom_name)
                # print(custom_data_path)
                # custom_df = pd.read_csv(custom_data_path)
                # custom_schema = _infer_schema_pandas_to_pyspark_standalone(custom_df)
                model_flag += "PIPELINE_SCHEMA={pipeline_schema}\n".format(
                    # pipeline_schema=json.dumps(custom_schema)
                    pipeline_schema=""
                )
        except FileNotFoundError:
            data_path = custom_name
            model_flag += "PIPELINE_SCHEMA={pipeline_schema}\n".format(
                # pipeline_schema=json.dumps(custom_schema)
                pipeline_schema=""
            )
        model_flag += "SOURCE_URL={data_path}\n".format(
            data_path=data_path
        )
    print(model_flag)

    with open(os.path.join(_BASE_PATH_, ".MODEL_FLAG"), "w") as f:
        f.write(model_flag)

class RunServerApp:
    def __init__(self,
                 log_refresh_time=0.1, *args, **kwargs):
        global dataset
        if "dataset" in vars() or "dataset" in globals():
            _dataset = dataset
        self.ready = False
        self.is_running = False
        self.log_refresh_time = log_refresh_time
        self.guide_msg = "\n".join([
            ("Open " + _colored("[Log Console]", "blue") + 
             " by selecting on the bottom of this notebook"
             + " or " +
            _colored("[View > Show Log Console]", "blue") +
            " in Menu,") + "and set 'Log Level' to " +
            _colored("[Info]", "cyan") + "."])
        self._base_schema_path = os.path.join(
            _base_data_dir_,
            ".columns.json",
        )
        if not os.path.exists(self._base_schema_path):
            _write_schema(_dataset, estimator_type=_DEFAULT_ESTM_TYPE_)

    def start(self):
        self.port = self.model_port_text.value
        self.model_name = self.model_name_text.value
        self.model_kind = self.model_kind_text.value
        self.model_dir = os.path.join(
            "file://", _BASE_PATH_, "airuntime", self.model_kind, "models")

        _data_info = os.path.join(
            _BASE_PATH_, "airuntime", self.model_kind_text.value, "data-info.json",
        )
        _data_schema = os.path.join(
            _BASE_PATH_, "airuntime", self.model_kind_text.value, "columns.json",
        )
        if os.path.exists(_data_info):
            os.remove(_data_info)
        if os.path.exists(_data_schema):
            os.remove(_data_schema)
        
        try:
            with open(self._base_schema_path, "r") as f:
                schema_info = json.load(f)
            with open(self._base_schema_path, "w") as f:
                if self.target_col_text:
                    schema_info.update({
                        "targetColumn": self.target_col_text.value,
                        "estimatorType": self.estimator_type_text.value,
                    })
                json.dump(schema_info, f)
        except FileNotFoundError:
            print(_colored("Dataset을 선택하여야 합니다."))

        _label_encoder_path = os.path.join(self.model_dir, "labelEncoder.joblib")
        if self.estimator_type_text.value != "classifier" and os.path.exists(_label_encoder_path):
            os.remove(_label_encoder_path)

        data_info_src = os.path.join("file://", _BASE_PATH_, self._base_schema_path)
        data_info_dst = os.path.join("file://", _data_schema)
        shutil.copy(data_info_src, data_info_dst)
        _write_model_flag(
            model_type=self.model_kind_text.value,
            data_type=self.data_type_text.value,
        )
        with self.output:
            print(
                _colored("running server '{}' ... ".format(self.model_name), "green"),
                end='', flush=True)

        try:
            if not _ray.is_initialized():
                _ray.init(
                    num_cpus=1,
                    num_gpus=None,
                    local_mode=False,
                    object_store_memory=(75 * 1024 * 1024),
                    _memory=(200 * 1024 * 1024),
                    _redis_max_memory=(100 * 1024 * 1024),
                    configure_logging=False,
                    logging_level=logging.INFO,
                    ignore_reinit_error=True,
                )
            self.server = _InternalServer.remote(
                model_name=self.model_name,
                model_dir=self.model_dir,
                model_kind=self.model_kind,
            )
            self.async_actor = _RunActorAsync.options(max_concurrency=2).remote(self.server)
            self.async_actor.run.remote(port=self.port)

            self.started.set()
            self.watching_log.set()
            with self.output:
                print(_colored("Succeeded.", "green"), flush=True)
            self.is_running = True
            self.start_stop_button.description = self._button_desc_changed
            self.start_stop_button.button_style = 'danger'

        except Exception as e:
            with self.output:
                print(
                    _colored(
                        "Server cannot be started. Please check your model saved.",
                        "red"
                    ),
                    _colored("Failed.", "red"),
                    "Go",
                    _colored("[View > Show Log Console]", "blue"),
                    "for details.",
                    flush=True)
            raise e

    def stop(self):
        _ray.kill(self.async_actor)
        _ray.kill(self.server)
        with self.output:
            print(
                _colored("closing server '{}' ... ".format(self.model_name), "red"),
                end='', flush=True)
        if not self.started.is_set():
            return

        if self.errored.is_set():
            with self.output:
                while not self.log.q.empty():
                    msg = self.log.q.get()
                    print(msg, end='', file=sys.stderr)

        with self.output:
            print(_colored("Succeeded.", "red"), flush=True)
        self.is_running = False
        self.watching_log.clear()
        self.exited.set()
        self.exiting.set()
        self.exited.wait()
        self.exiting.clear()
        self.start_stop_button.description = self._button_desc_base
        self.start_stop_button.button_style = 'success'
        time.sleep(0.1)

    # Widget Methods
    def _create_widgets(self):
        self.output = Output(layout={'border': '1px solid black'})
        with self.output:
            print(self.guide_msg)
        self.started = multiprocessing.Event()
        self.exiting = multiprocessing.Event()
        self.exited = multiprocessing.Event()
        self.errored = multiprocessing.Event()

        self._button_desc_base = 'Test Server: Start'
        self._button_desc_changed = 'Test Server: Stop'
        self.start_stop_button = Button(description=self._button_desc_base)
        self.start_stop_button.on_click(self._toggle_start_and_stop)
        self.start_stop_button.button_style = 'success'
        self.clear_log_button = Button(description='clear log')
        self.clear_log_button.on_click(lambda evt: self.clear_log())

        self.log = _LogToQueue()
        self.watching_log = multiprocessing.Event()

        text_style = {'description_width': '120px'}
        self.model_port_text = Text(
            description='Port',
            value='8080',
            style=text_style,
        )
        self.model_name_text = Text(
            description='Name',
            value='test',
            style=text_style,
        )
        self.model_kind_text = Dropdown(
            description='Kind',
            options=_MODEL_TYPE_LIST_,
            value=_DEFAULT_MODEL_TYPE_,
            style=text_style,
        )
        self.data_type_text = Dropdown(
            description='Data Type',
            options=_DATA_TYPE_LIST_,
            value=_DEFAULT_DATA_TYPE_,
            style=text_style,
        )
        self.target_col_text = Text(
            description='Target Col',
            value=_DEFAULT_TARGET_COL_,
            style=text_style,
        )
        self.estimator_type_text = Dropdown(
            description='Estimator',
            options=_ESTM_TYPE_LIST_,
            value=_DEFAULT_ESTM_TYPE_,
            style=text_style,
        )

    def _toggle_start_and_stop(self, change):
        if self.is_running:
            self.stop()
        else:
            self.start()

    def refresh_log(self):
        refreshed_once = False

        while self.watching_log.is_set() or not refreshed_once:
            refreshed_once = True

            if self.exited.is_set():
                self.watching_log.clear()
                # self.__disable_buttons_after_exited()

            while not self.log.empty():
                msg = self.log.get()
                with self.output:
                    if self.errored.is_set():
                        print(msg, end='', file=sys.stderr)
                    else:
                        print(msg, end='')
                if self.exited.is_set() and self.log.empty():
                    return

            time.sleep(self.log_refresh_time) # save a few CPU cycles

    def clear_log(self, wait=False):
        self.output.clear_output(wait=wait)
        with self.output:
            print(self.guide_msg)

    def show_log(self):
        display(self.output)

    def display_widgets(self):
        self._create_widgets()
        display(VBox([HBox([
            VBox([
                self.start_stop_button,
                self.clear_log_button,
            ]),
            VBox([
                self.model_port_text,
                self.model_name_text,
                self.model_kind_text,
                self.data_type_text,
                self.target_col_text,
                self.estimator_type_text,
            ])]),
            self.output]))


_server_app = RunServerApp()

_base_data_dir_ = os.path.join(_BASE_PATH_, "dataset")
__default_data_info_path = os.path.join(_BASE_PATH_, "dataset", "data-info.json")
if os.path.exists(__default_data_info_path):
    with open(__default_data_info_path, "r") as f:
        __default_data_info = json.load(f)[0]
    __default_filename = os.path.join(__default_data_info.get("filename"))
else:
    __default_filename = os.path.basename(_base_data_dir_)

# Create and display a FileChooser widget
_fc = _FileChooser(
    _base_data_dir_,
    filename=__default_filename,
    select_default=False,
    # sandbox_path=_BASE_PATH_,
    sandbox_path=_base_data_dir_,
    show_hidden=False,
    use_dir_icons=True,
    show_only_dirs=False,
    filter_pattern=['*.txt', '*.csv'],
    title=f'Select Dataset from <b>`dataset`</b> directory. Variable named<b style="color:red;"><i>`dataset`</i></b> will be used instead in case of <b>`No Selection`.</b>',

)

display(_fc)


# Sample callback function
def _read_data(chooser):
    global _fc
    global _data_path
    global dataset
    global _dataset
    _data_path = _fc.selected
    chooser.title = f"Dataset selected from <b>`dataset`</b> directory: {_data_path}"
    try:
        pipeline_data_info, _ = _load_schema()
        if pipeline_data_info["filename"] == _data_path:
            if "dataset" in vars() or "dataset" in globals():
                _dataset = dataset
            else:
                _dataset = _read_pandas_df(printout=False)
        else:
            _dataset = pd.read_csv(_data_path)
    except Exception:
        pipeline_data_info = None
        if "dataset" in vars() or "dataset" in globals():
            _dataset = dataset
        else:
            _dataset = pd.read_csv(_data_path)

    _write_schema(_dataset, data_path=_data_path)
    

# Register callback function
_fc.register_callback(_read_data)

_server_app.display_widgets()
