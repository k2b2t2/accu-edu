import json
from ipywidgets import (
    Button, Output, HBox, VBox,
    Text, Textarea, FileUpload, Layout, Tab, Accordion)
from termcolor import colored
import numpy as np
import pandas as pd
from runtime_client import KFServingClient as _KFServingClient
from typing import Union


def _create_sample_json(
        data: Union[pd.DataFrame, np.ndarray],
        indent: int = 4,
        ) -> str:
    if isinstance(data, pd.DataFrame):
        data = data.dropna()
        try:
            if "_TARGET_COL_" in vars() or "_TARGET_COL_" in globals():
                global _TARGET_COL_
                if _TARGET_COL_ is not None:
                    _EX_COL_ = _TARGET_COL_
                else:
                    raise Exception("'_TARGET_COL_' is None.")
            else:
                raise Exception("'_TARGET_COL_' is not defined.")
        except:
            _EX_COL_ = None
        if _EX_COL_ is None:
            target = data.iloc[:2, :]
        else:
            target = data[data.columns.drop([_EX_COL_])].iloc[:2, :]
        
        return json.dumps({
            "instances": json.loads(target.to_json(orient="values")),
            "labels": target.columns.tolist(),
            },
            indent=indent,
        )
    elif isinstance(data, np.ndarray):
        if len(data.shape) != 2:
            raise ValueError("Numpy Array를 사용하려면 2D Array여야 합니다.")
        else:
            target = pd.DataFrame(data[:2])
            return json.dumps({
                "instances": json.loads(target.to_json(orient="values")),
                },
                indent=indent,
            )
    else:
        raise TypeError("""지원하지 않는 객체 형식입니다.
2-Dimensional {pandas.DataFrame, numpy.ndarray} 를 사용하여야 합니다.""")


class _ClientWidget:
    def __init__(self):
        self.send_button = Button(description="Send", icon='check', button_style="success")
        self.send_button.on_click(self.send)
        self.clear_input_button = Button(description="Clear Input")
        self.clear_input_button.on_click(self.clear_input)
        
        self.clear_output_button = Button(description="Clear Output")
        self.clear_output_button.on_click(self.clear_output)
        self.output = Output(layout={'border': '1px solid black'})

        _json_text_sample = '''{
    "instances": [
        ...
    ],
    "labels": [ 
        (Optional)
    ]
}'''
        try:
            if "dataset" in vars() or "dataset" in globals():
                global dataset
                if dataset is not None and isinstance(dataset, (pd.DataFrame, np.ndarray)):
                    self.json_text_sample = _create_sample_json(dataset, indent=4)
                else:
                    raise Exception("'dataset' is None or not typed as {pd.DataFrame, np.ndarray}")
            elif "_dataset" in vars() or "_dataset" in globals():
                global _dataset
                if _dataset is not None and isinstance(_dataset, (pd.DataFrame, np.ndarray)):
                    self.json_text_sample = _create_sample_json(_dataset, indent=4)
                else:
                    raise Exception("'_dataset' is None or not typed as {pd.DataFrame, np.ndarray}")
            else:
                raise Exception("'dataset' is not defined.")
        except:
            self.json_text_sample = _json_text_sample

        self.ndarray_sample = "Enter the variable name here."

        self.model_port_text = Text(description='Server Port', value='8080')
        self.model_name_text = Text(description='Server Name', value='test')


        self.json_text = Textarea(
            value=self.json_text_sample,
            placeholder='Type something',
            description='json',
            disabled=False,
            rows=15,
            layout=Layout(width="75%"),
        )
        
        self.uploader = FileUpload(
            accept='',  # Accepted file extension e.g. '.txt', '.pdf', 'image/*', 'image/*,.pdf'
            multiple=False  # True to accept multiple files upload else False
        )

        self.ndarray_name = Text(
            value=self.ndarray_sample,
            placeholder='Type something',
            description='name',
            disabled=False,
            rows=15,
            layout=Layout(width="75%"),
        )

        tab_contents = ["JSON", "File", "numpy.ndarray"]
        button_box = VBox([
            self.send_button,
            self.clear_input_button,
            self.clear_output_button,
        ])
        children = [
            HBox([button_box, self.json_text]),
            HBox([button_box, self.uploader]),
            HBox([button_box, self.ndarray_name]),
        ]
        self.tab = Tab()
        self.tab.children = children
        for i, name in enumerate(tab_contents):
            self.tab.set_title(i, str(name))

        self.client_widget = VBox([self.model_port_text, self.model_name_text, self.tab, self.output])

        self.guide_msg = "\n".join(["client is ready.", "-" * 50])

        with self.output:
            print(self.guide_msg)
        display(self.client_widget)

    def send(self, change):
        client = _KFServingClient("http://localhost:{}".format(self.model_port_text.value))
        activated_tab = self.tab.selected_index
        
        if activated_tab == 0:
            self._send_json(client)
        elif activated_tab == 2:
            self._send_ndarray(client)
                    
    def _send_json(self, client):
        with self.output:
            print(colored("Request to [{}] ...".format(self.model_name_text.value), "blue"))
            print(colored("Input " +  "=" * 51, "blue"))
            print(json.loads(self.json_text.value))
        result = client.infer(model_nm=self.model_name_text.value, data=json.loads(self.json_text.value))

        with self.output:
            print(colored("Output " +  "=" * 50, "green"))
            if result.ok:
                print(result.json())
            else:
                print(result.status_code)
    
    def _send_ndarray(self, client):
        request_ndarray = globals()[self.ndarray_name.value]
        with self.output:
            print(colored("Request to [{}] ...".format(self.model_name_text.value), "blue"))
            print(colored("Input " +  "=" * 51, "blue"))
            print(request_ndarray)
        result = client.infer(model_nm=self.model_name_text.value, data=request_ndarray)

        with self.output:
            print(colored("Output " +  "=" * 50, "green"))
            if result.ok:
                print(result.json())
            else:
                print(result.status_code)

    def clear_output(self, change, wait=False):
        self.output.clear_output(wait=wait)
        with self.output:
            print(self.guide_msg)

    def clear_input(self, change):
        self.json_text.value = self.json_text_sample
        self.ndarray_name.value = self.ndarray_sample

_client_widget = _ClientWidget()