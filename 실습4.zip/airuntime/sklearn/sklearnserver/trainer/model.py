from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from ._core import BaseModel
from .preprocessor import prep_func
from .preprocessor_for_pipeline import prep_func as prep_func_pipeline
from .postprocessor import post_func
from . import config

import os
import joblib
import numpy as np
import pandas as pd
from typing import Union

from sklearn.tree import DecisionTreeClassifier
from sklearn.pipeline import Pipeline


__all__ = ['SKLearnModel']


class SKLearnModel(BaseModel):

    def __init__(self, dirpath=None, *args, **kwargs):
        self.filename = "item_based_collabor"
        super().__init__(dirpath=dirpath, *args, **kwargs)
        self.config = config

    def predict(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        outputs = []
        for i, row in X.iterrows():
            pred = self.item_based_collabor[row['movie_name']].sort_values(ascending=False)[:row['top_n']+1]
            outputs.append([item for item in zip(pred.index, np.round(pred.values, 2)) if item[0] != row['movie_name']])
        return outputs

    def load(self, dirpath, *args, **kwargs):
        self.item_based_collabor = pd.read_pickle(os.path.join(dirpath, self.filename))

