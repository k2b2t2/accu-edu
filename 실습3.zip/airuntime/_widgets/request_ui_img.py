import json
from ipywidgets import (
    Button, Output, HBox, VBox,
    Text, Textarea, FileUpload, Layout, Tab, Accordion)
from termcolor import colored
import numpy as np
import pandas as pd
from runtime_client import KFServingClient as _KFServingClient
from typing import Union
from PIL import Image


def _create_sample_json(
        img_path: str,
        indent: int = 4,
        ) -> str:
    img_path = img_path
    img = Image.open(img_path)
    sample_img_arr = np.array([np.asarray(img)])
    
    return json.dumps({
                "instance_type": "numpy",
                "instances": sample_img_arr.tolist(),
                },
                indent=indent,
            )


class _ClientWidget:
    def __init__(self):
        self.send_button = Button(description="Send", icon='check', button_style="success")
        self.send_button.on_click(self.send)
        self.clear_input_button = Button(description="Clear Input")
        self.clear_input_button.on_click(self.clear_input)
        
        self.clear_output_button = Button(description="Clear Output")
        self.clear_output_button.on_click(self.clear_output)
        self.output = Output(layout={'border': '1px solid black'})

        _json_image_sample = '''{
    "instance_type": "numpy",
    "instances": [
        ...
    ]
}'''
        img_path = '/home/work/dataset/cifar10_airplane_sample.jpeg'
        self.json_image_sample = _create_sample_json(img_path, indent=4)
        self.ndarray_sample = "Enter the variable name here."

        self.model_port_text = Text(description='Server Port', value='8080')
        self.model_name_text = Text(description='Server Name', value='test')

        self.json_image = Textarea(
            value=self.json_image_sample,
            placeholder='Type something',
            description='json',
            disabled=False,
            rows=15,
            layout=Layout(width="75%"),
        )
        
        self.uploader = FileUpload(
            accept='',  # Accepted file extension e.g. '.txt', '.pdf', 'image/*', 'image/*,.pdf'
            multiple=False  # True to accept multiple files upload else False
        )

        self.ndarray_name = Text(
            value=self.ndarray_sample,
            placeholder='Type something',
            description='name',
            disabled=False,
            rows=15,
            layout=Layout(width="75%"),
        )

        tab_contents = ["JSON", "File", "numpy.ndarray"]
        button_box = VBox([
            self.send_button,
            self.clear_input_button,
            self.clear_output_button,
        ])
        children = [
            HBox([button_box, self.json_image]),
            HBox([button_box, self.uploader]),
            HBox([button_box, self.ndarray_name]),
        ]
        self.tab = Tab()
        self.tab.children = children
        for i, name in enumerate(tab_contents):
            self.tab.set_title(i, str(name))

        self.client_widget = VBox([self.model_port_text, self.model_name_text, self.tab, self.output])

        self.guide_msg = "\n".join(["client is ready.", "-" * 50])

        with self.output:
            print(self.guide_msg)
        display(self.client_widget)

    def send(self, change):
        client = _KFServingClient("http://localhost:{}".format(self.model_port_text.value))
        activated_tab = self.tab.selected_index
        
        if activated_tab == 0:
            self._send_json(client)
        elif activated_tab == 2:
            self._send_ndarray(client)
                    
    def _send_json(self, client):
        with self.output:
            print(colored("Request to [{}] ...".format(self.model_name_text.value), "blue"))
            print(colored("Input " +  "=" * 51, "blue"))
            print(json.loads(self.json_image.value))
        result = client.infer(model_nm=self.model_name_text.value, data=json.loads(self.json_image.value))

        with self.output:
            print(colored("Output " +  "=" * 50, "green"))
            if result.ok:
                print(result.json())
            else:
                print(result.status_code)
    
    def _send_ndarray(self, client):
        request_ndarray = globals()[self.ndarray_name.value]
        with self.output:
            print(colored("Request to [{}] ...".format(self.model_name_text.value), "blue"))
            print(colored("Input " +  "=" * 51, "blue"))
            print(request_ndarray)
        result = client.infer(model_nm=self.model_name_text.value, data=request_ndarray)

        with self.output:
            print(colored("Output " +  "=" * 50, "green"))
            if result.ok:
                print(result.json())
            else:
                print(result.status_code)

    def clear_output(self, change, wait=False):
        self.output.clear_output(wait=wait)
        with self.output:
            print(self.guide_msg)

    def clear_input(self, change):
        self.json_image.value = self.json_image_sample
        self.ndarray_name.value = self.ndarray_sample

_client_widget = _ClientWidget()