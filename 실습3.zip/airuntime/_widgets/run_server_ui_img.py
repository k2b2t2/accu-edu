from genericpath import exists
import time
import asyncio
import multiprocessing
import os
import logging
from termcolor import colored as _colored

import os
import json
from typing import Union, List, Dict, Tuple
import numpy as np
import pandas as pd

from ipywidgets import Button, Layout, Output, HBox, VBox, Text, Dropdown
from IPython.display import display

from ipyfilechooser import FileChooser as _FileChooser

import kfserving as _kfserving
import ray as _ray 

import sys
import shutil

from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter


try:
    from startup import (
        _infer_decimal,
        _read_pandas_df,
    )
except ImportError:
    try:
        from ..startup import (
            _infer_decimal,
            _read_pandas_df,
        )
    except ImportError:
        _BASE_PATH_ = "/home/work"
        _PACKAGE_ROOT_ = os.path.join(_BASE_PATH_, "airuntime")
        _PACKAGE_PATH_ = [
            os.path.join(_PACKAGE_ROOT_, p) for p in os.listdir(_PACKAGE_ROOT_)
            if os.path.isdir(os.path.join(_PACKAGE_ROOT_, p)) or os.path.basename(p).endswith(".py")
        ]
        sys.path.insert(0, _BASE_PATH_)
        sys.path.insert(-1, _PACKAGE_ROOT_)
        for _p in _PACKAGE_PATH_:
            sys.path.insert(0, _p)

        from startup import (
            _infer_decimal,
            _read_pandas_df,
        )


import importlib


_parser = ArgumentParser(formatter_class=ArgumentDefaultsHelpFormatter)
_parser.add_argument("-k", "--kind", help='model type ["tensorflow", "pytorch"]', required=True)
_args = vars(_parser.parse_args())
_DEFAULT_MODEL_TYPE_ = _args["kind"]
_DEFAULT_TARGET_COL_ = "label"

assert _DEFAULT_MODEL_TYPE_ in ["tensorflow", "pytorch"]
_MODEL_TYPE_LIST_ = [_DEFAULT_MODEL_TYPE_]

_FW_VERSION_DICT_ = {
    "tensorflow": "2.3.1",
    "pytorch": "1.7.1",
}

_DEFAULT_DATA_TYPE_ = "Image"

_DEFAULT_ESTM_TYPE_ = "classifier"

if _ray.is_initialized():
    _ray.shutdown()

_ray.init(
    num_cpus=1,
    num_gpus=None,
    local_mode=False,
    # object_store_memory=(75 * 1024 * 1024),
    # _memory=(200 * 1024 * 1024),
    _redis_max_memory=(100 * 1024 * 1024),
    include_dashboard=False,
    configure_logging=False,
    logging_level=logging.INFO,
    ignore_reinit_error=True,
    _plasma_directory="/tmp",
    _system_config={
        "automatic_object_spilling_enabled": True,
        "object_spilling_config": json.dumps(
            {"type": "filesystem", "params": {"directory_path": "/tmp/spill"}},
        )
    },
)
_RAY_ROTATION_BACKUP_COUNT_ = 1


class _LogToQueue(logging.Handler):
    def __init__(self, queue=None):
        self.q = queue if queue else multiprocessing.Queue()
        logging.Handler.__init__(self)
    def write(self,x):
        return self.q.put(x)
    def put(self,x):
        return self.q.put(x)
    def get(self):
        return self.q.get()
    def empty(self):
        return self.q.empty()
    def print(self, x, end='\n'):
        self.write(str(x) + end)


@_ray.remote  # (memory=(50 * 1024 * 1024))  # 50MB
class _InternalServer:
    def __init__(self, model_name="test", model_dir=None, model_kind=None):
        self.model_name = model_name
        self.model_dir = model_dir
        self.model_kind = model_kind
        import sys
        sys.path.insert(0, _BASE_PATH_)
        self.model_module = importlib.import_module(
            f"airuntime.{self.model_kind}.{self.model_kind.split('_')[0]}server")
        self.model = self.model_module.inferencer.model.ServingModel(
            self.model_name, self.model_dir
        )
        try:
            self.model.load()
            self.ready = True
        except Exception as e:
            self.ready = False
            raise e

    async def run(self, port=8080):
        self.port = port
        # For KFServer IOLoop
        try:
            #asyncio.set_event_loop(asyncio.new_event_loop())
            self.server = _kfserving.KFServer(
                http_port=self.port,
                registered_models=self.model_module.inferencer.model_repository.ModelRepository(
                    self.model_dir
                )
            )
            await self.server.start([self.model])
        except RuntimeError as re:
            pass

@_ray.remote  # (memory=(50 * 1024 * 1024))  # 50MB
class _RunActorAsync:
    def __init__(self, actor):
        self.actor = actor

    async def run(self, *args, **kwargs):
        try:
            # Coroutine will switch context when "await" is called.
            res = await self.actor.run.remote(*args, **kwargs)
        except Exception as e:
            raise e


def _write_model_flag(
        model_type: str="tensorflow"
        ):
    data_type = "Image"
    fw_name = model_type
    if fw_name == "pytorch":
        pkg_name = "torch"
    else:
        pkg_name = fw_name
    fw_module = importlib.import_module(pkg_name)
    try:
        fw_version = fw_module.__version__ if fw_module.__version__ else _FW_VERSION_DICT_.get(pkg_name)
    except AttributeError:
        fw_version = _FW_VERSION_DICT_.get(pkg_name)
    model_flag = """# This file is a SYSTEM-GENERATED file. DO NOT EDIT THIS!!!

MODEL_TYPE={model_type}
FW={fw_name}
FW_VERSION={fw_version}
DATA_TYPE={data_type}
MODEL_TEST=/home/work/airuntime/{model_type}/test_server.py
PIPELINE_SCHEMA=
SOURCE_URL=dataset/cifar10_airplane_sample.jpeg
""".format(
    model_type=model_type,
    fw_name=fw_name,
    fw_version=fw_version,
    data_type=data_type,
)
    print(model_flag)

    with open(os.path.join(_BASE_PATH_, ".MODEL_FLAG"), "w") as f:
        f.write(model_flag)

class RunServerApp:
    def __init__(self,
                 log_refresh_time=0.1, *args, **kwargs):
        global dataset
        if "dataset" in vars() or "dataset" in globals():
            _dataset = dataset
        self.ready = False
        self.is_running = False
        self.log_refresh_time = log_refresh_time
        self.guide_msg = "\n".join([
            ("Open " + _colored("[Log Console]", "blue") + 
             " by selecting on the bottom of this notebook"
             + " or " +
            _colored("[View > Show Log Console]", "blue") +
            " in Menu,") + "and set 'Log Level' to " +
            _colored("[Info]", "cyan") + "."])

    def start(self):
        self.port = self.model_port_text.value
        self.model_name = self.model_name_text.value
        self.model_kind = self.model_kind_text.value
        self.model_dir = os.path.join(
            "file://", _BASE_PATH_, "airuntime", self.model_kind, "models")

        _write_model_flag(
            model_type=self.model_kind_text.value
        )
        with self.output:
            print(
                _colored("running server '{}' ... ".format(self.model_name), "green"),
                end='', flush=True)

        try:
            if not _ray.is_initialized():
                _ray.init(
                    num_cpus=1,
                    num_gpus=None,
                    local_mode=False,
                    object_store_memory=(75 * 1024 * 1024),
                    _memory=(200 * 1024 * 1024),
                    _redis_max_memory=(100 * 1024 * 1024),
                    configure_logging=False,
                    logging_level=logging.INFO,
                    ignore_reinit_error=True,
                )
            self.server = _InternalServer.remote(
                model_name=self.model_name,
                model_dir=self.model_dir,
                model_kind=self.model_kind,
            )
            self.async_actor = _RunActorAsync.options(max_concurrency=2).remote(self.server)
            self.async_actor.run.remote(port=self.port)

            self.started.set()
            self.watching_log.set()
            with self.output:
                print(_colored("Succeeded.", "green"), flush=True)
            self.is_running = True
            self.start_stop_button.description = self._button_desc_changed
            self.start_stop_button.button_style = 'danger'

        except Exception as e:
            with self.output:
                print(
                    _colored(
                        "Server cannot be started. Please check your model saved.",
                        "red"
                    ),
                    _colored("Failed.", "red"),
                    "Go",
                    _colored("[View > Show Log Console]", "blue"),
                    "for details.",
                    flush=True)
            raise e

    def stop(self):
        _ray.kill(self.async_actor)
        _ray.kill(self.server)
        with self.output:
            print(
                _colored("closing server '{}' ... ".format(self.model_name), "red"),
                end='', flush=True)
        if not self.started.is_set():
            return

        if self.errored.is_set():
            with self.output:
                while not self.log.q.empty():
                    msg = self.log.q.get()
                    print(msg, end='', file=sys.stderr)

        with self.output:
            print(_colored("Succeeded.", "red"), flush=True)
        self.is_running = False
        self.watching_log.clear()
        self.exited.set()
        self.exiting.set()
        self.exited.wait()
        self.exiting.clear()
        self.start_stop_button.description = self._button_desc_base
        self.start_stop_button.button_style = 'success'
        time.sleep(0.1)

    # Widget Methods
    def _create_widgets(self):
        self.output = Output(layout={'border': '1px solid black'})
        with self.output:
            print(self.guide_msg)
        self.started = multiprocessing.Event()
        self.exiting = multiprocessing.Event()
        self.exited = multiprocessing.Event()
        self.errored = multiprocessing.Event()

        self._button_desc_base = 'Test Server: Start'
        self._button_desc_changed = 'Test Server: Stop'
        self.start_stop_button = Button(description=self._button_desc_base)
        self.start_stop_button.on_click(self._toggle_start_and_stop)
        self.start_stop_button.button_style = 'success'
        self.clear_log_button = Button(description='clear log')
        self.clear_log_button.on_click(lambda evt: self.clear_log())

        self.log = _LogToQueue()
        self.watching_log = multiprocessing.Event()

        text_style = {'description_width': '120px'}
        self.model_port_text = Text(
            description='Port',
            value='8080',
            style=text_style,
        )
        self.model_name_text = Text(
            description='Name',
            value='test',
            style=text_style,
        )
        self.model_kind_text = Dropdown(
            description='Kind',
            options=_MODEL_TYPE_LIST_,
            value=_DEFAULT_MODEL_TYPE_,
            style=text_style,
        )

    def _toggle_start_and_stop(self, change):
        if self.is_running:
            self.stop()
        else:
            self.start()

    def refresh_log(self):
        refreshed_once = False

        while self.watching_log.is_set() or not refreshed_once:
            refreshed_once = True

            if self.exited.is_set():
                self.watching_log.clear()
                # self.__disable_buttons_after_exited()

            while not self.log.empty():
                msg = self.log.get()
                with self.output:
                    if self.errored.is_set():
                        print(msg, end='', file=sys.stderr)
                    else:
                        print(msg, end='')
                if self.exited.is_set() and self.log.empty():
                    return

            time.sleep(self.log_refresh_time) # save a few CPU cycles

    def clear_log(self, wait=False):
        self.output.clear_output(wait=wait)
        with self.output:
            print(self.guide_msg)

    def show_log(self):
        display(self.output)

    def display_widgets(self):
        self._create_widgets()
        display(VBox([HBox([
            VBox([
                self.start_stop_button,
                self.clear_log_button,
            ]),
            VBox([
                self.model_port_text,
                self.model_name_text,
                self.model_kind_text
            ])]),
            self.output]))


_server_app = RunServerApp()

# Create and display a FileChooser widget
_fc = _FileChooser(
    os.path.join(_BASE_PATH_, 'dataset'),
    filename='cifar10_airplane_sample.jpeg',
    select_default=False,
    sandbox_path=_BASE_PATH_,
    show_hidden=False,
    use_dir_icons=True,
    show_only_dirs=False,
    filter_pattern=['*.jpeg'],
    title=f'Select Dataset from <b>`dataset`</b> directory. Variable named<b style="color:red;"><i>`dataset`</i></b> will be used instead in case of <b>`No Selection`.</b>',

)

display(_fc)

_server_app.display_widgets()
