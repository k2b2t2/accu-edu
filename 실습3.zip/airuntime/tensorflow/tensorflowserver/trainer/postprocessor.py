import numpy as np


def post_func(outputs):
    label = ['Airplane', 'Automobile', 'Bird', 'Cat', 'Deer', 'Dog', 'Frog', 'Horse', 'Ship', 'Truck']
    pred_label = [label[i] for i in np.argmax(outputs, axis=1)]
    return np.array(pred_label)