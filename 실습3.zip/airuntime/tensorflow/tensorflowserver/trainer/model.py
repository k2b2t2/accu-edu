from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from ._core import BaseModel
from .preprocessor import prep_func
from .postprocessor import post_func
from . import config

from typing import Union, Tuple, List

import os
import joblib
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
import tensorflow.keras.backend as K
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Flatten, Dense, Dropout
from tensorflow.keras.layers import BatchNormalization, Conv2D
from tensorflow.keras.layers import MaxPool2D, Activation, MaxPooling2D, AveragePooling2D

__all__ = [
    'input_dataset_fn',
    'TensorflowModel',
]

MODEL_VERSION = "1"


def input_dataset_fn(features, labels, shuffle, batch_size, num_epochs: int=None):
    if labels is None:
        inputs = features
    else:
        inputs = (features, labels)
    dataset = tf.data.Dataset.from_tensor_slices(inputs)

    if shuffle:
        dataset = dataset.shuffle(buffer_size=len(features))

    # We call repeat after shuffling, rather than before, to prevent separate
    # epochs from blending together.
    if num_epochs:
        dataset = dataset.repeat(num_epochs)
    dataset = dataset.batch(batch_size, drop_remainder=True)
    return dataset

def recall_m(y_true, y_pred):
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
    recall = true_positives / (possible_positives + K.epsilon())
    return recall

def precision_m(y_true, y_pred):
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    predicted_positives =K.sum(K.round(K.clip(y_pred, 0, 1)))
    precision = true_positives / (predicted_positives + K.epsilon())
    return precision

def f1_score(y_true, y_pred):
    precision = precision_m(y_true, y_pred)
    recall = recall_m(y_true, y_pred)
    return ( 2 * recall * precision) / (recall + precision+ K.epsilon())

class TensorflowModel(BaseModel):

    def __init__(self, is_build=False, dirpath=None):
        
        self.is_preprocessed = False
        self.model_version = MODEL_VERSION
        if is_build:
            self.build()
        elif dirpath:
            self.load(dirpath)
        else:
            raise Exception("'is_build' or 'dirpath' must be given.")

    def build(self):
        
        #buiding model
        model = Sequential()

        model.add(Conv2D(64,activation = 'relu',kernel_size = (3,3 ), input_shape=(32, 32, 3)))
        model.add(MaxPooling2D(pool_size = (2,2)))
        model.add(BatchNormalization())
        model.add(Conv2D(32, activation = 'relu', kernel_size = (3,3 )))
        model.add(BatchNormalization())
        model.add(Flatten(input_shape = (32,32,3)))
        model.add(Dropout(0.2))
        model.add(Dense(80, activation = 'relu'))
        model.add(Dropout(0.2))
        model.add(Dense(10, activation = 'softmax'))

        #compilation of  model
        model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

        self.model = model

        
    def preprocess(self, X: Union[np.ndarray, pd.DataFrame]) -> np.ndarray:
        # Case 1: `prep_func` is made for the batch `X`
        X = prep_func(X, self.is_preprocessed)
        # Case 2: `prep_func` is made for each input in `X`
        # X = np.array([prep_func(x) for x in X])
        return X.values if isinstance(X, pd.DataFrame) else X

    def postprocess(self, y_hat: np.ndarray) -> np.ndarray:
        # Case 1: `post_func` is made for the batch `y_hat`
        y_hat = post_func(y_hat)
        # Case 2: `post_func` is made for each output in `y_hat`
        # y_hat = np.array([post_func(yh) for yh in y_hat])
        return y_hat

    def train(self, X_train, y_train, valid,
              num_epochs=10,
              verbose=1,
              # validation_data=valid,
              # validation_split=0.3,
              callbacks=None):
        self.is_preprocessed = True
        self.history = self.model.fit(x=X_train,
                                      y=y_train,
                                      epochs=num_epochs,
                                      verbose=verbose,
                                      validation_data=valid)
                                      # validation_split=validation_split)

    def evaluate(self, *args, **kwargs):
        return self.model.evaluate(*args, **kwargs)

    def predict(self, inputs):
        prep = self.preprocess(inputs)
        y_hat = self.model.predict(
            prep, batch_size=None, verbose=0,
            steps=None, callbacks=None,
            max_queue_size=10, workers=1,
            use_multiprocessing=False,
        )
        return self.postprocess(y_hat)

    def save(self, dirpath, include_optimizer=True,
             *args, **kwargs):
        self.model.save(os.path.join(dirpath, self.model_version),
                        overwrite=True,
                        include_optimizer=include_optimizer,
                        save_format='tf',
                        *args, **kwargs)

    def load(self, dirpath, *args, **kwargs):
        self.model = tf.keras.models.load_model(
            os.path.join(dirpath, self.model_version),
            compile=False,
            *args, **kwargs)
