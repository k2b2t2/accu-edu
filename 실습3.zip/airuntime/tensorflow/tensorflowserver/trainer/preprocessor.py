__all__ = ['prep_func']


def prep_func(inputs, is_preprocessed=False):
    if not is_preprocessed:
        inputs = inputs/255.0
    return inputs
