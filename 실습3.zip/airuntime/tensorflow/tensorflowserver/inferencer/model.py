# Copyright 2021 .
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import kfserving
import numpy as np
import pandas as pd
import os
import io
from typing import Union, Dict, List
from .utils import change_ndarray_tolist
import logging

import io
import zlib
import pickle

try:
    # KEEP THIS ORDER
    # 1. Import `input_schema` = pandas_schema
    # 2. Override customSchema as `input_schema` if exists
    # 3. Use user-defined `input_schema` in preprocessor
    #    if the system given schemas{pandas_schema, customSchema} are not exist
    # `warm start` canceled if all not found.
    from ..trainer.preprocessor_for_pipeline import pandas_schema as input_schema
    from ..trainer.preprocessor_for_pipeline import customSchema as input_schema
    warm_start = True
except ImportError:
    try:
        from ..trainer.preprocessor import input_schema
        warm_start = True
    except ImportError:
        warm_start = False

try:
    from pyspark.sql.types import *
except ModuleNotFoundError:
    warm_start = False

from ..trainer.model import TensorflowModel


log = logging.getLogger(__name__)


class ServingModel(kfserving.KFModel):  # pylint:disable=c-extension-no-member
    def __init__(self, name: str, model_dir: str):
        super().__init__(name)
        self.name = name
        self.model_dir = model_dir
        self.ready = False

    def load(self) -> bool:
        model_path = kfserving.Storage.download(self.model_dir)

        self._model = TensorflowModel(
            dirpath=os.path.join(model_path))

        # Warm-start
        if warm_start:
            try:
                if isinstance(input_schema, dict):
                    input_dummy = {key: [None] if value in ["str", "object"] else [0] for key, value in
                                   input_schema.items()}
                else:
                    input_dummy = {c.name: [0] if isinstance(c.dataType, (
                        IntegerType, ShortType, LongType, BinaryType, BooleanType, FloatType, DoubleType))
                    else [None] for c in input_schema}
                input_dummy = pd.DataFrame(input_dummy)
                self._model.predict(input_dummy)
                log.info("Warm-start has succeeded.")
            except Exception as e:
                log.warning(f"Warm-start has canceled with: {e}")
        else:
            log.info("Warm-start not activated: `input_schema` not found.")

        self.ready = True
        return self.ready


    def _predict_from_json(self, request: Dict) -> Dict:
        if request.get("instance_type") == "numpy":
            input_data = np.array(request["instances"])
        else:
            input_data = pd.DataFrame(
                request["instances"],
                columns=request.get("columns", request.get("labels")),
            )
        try:
            result = self._model.predict(input_data).tolist()
            return {
                "predictions": result,
                "model_version": os.getenv("MODEL_VERSION", self._model.model_version)
            }
        except Exception as e:
            raise Exception("Failed to predict %s" % e)

    def _predict_from_bytes(self, request: bytes) -> Dict:
        parsed_request = MultipartRequest(request)
        instances: np.ndarray = parsed_request.instances
        input_df = pd.DataFrame(instances)  # without column names: by order
        try:
            predictions = self._model.predict(instances).tolist()
            return {
                "predictions": predictions,
                "model_version": os.getenv("MODEL_VERSION", self._model.model_version)
            }
        except Exception as e:
            raise Exception("Failed to predict %s" % e)

    def predict(self, request: Union[Dict, bytes]) -> Dict:
        if isinstance(request, dict):
            return self._predict_from_json(request)
        elif isinstance(request, bytes):
            return self._predict_from_bytes(request)
        else:
            raise Exception("Unsupported 'Content-Type': 'json' or 'multipart/form-data is available.")


class MultipartRequest:
    # boundary: bytes
    # content_disposition: str
    # content_type: str
    # name: str
    # filename: str
    data_bytes: bytes
    instances: np.ndarray

    def __init__(self, request: bytes):
        _info, data_bytes = request.split(b'\r\n\r\n')[:2]
        self.data_bytes = data_bytes

        try:
            npz = np.load(io.BytesIO(data_bytes), allow_pickle=True)
            self.instances = npz[npz.files[0]]
        except Exception as e:
            raise Exception(
                "Unsupported or invalid File Format: " +
                "'npz', 'npy' or 'pkl' format is avaliable.: {}" % e)

    def __repr__(self):
        return str(self)

    def __str__(self):
        return str(self.__dict__)
